<script setup lang="ts">
import { RouterView, useRoute } from 'vue-router'
import { NConfigProvider, NMessageProvider, darkTheme, lightTheme } from 'naive-ui'
import { useStorage } from '@vueuse/core'

// 主题状态管理
const isDark = useStorage('theme-mode', false)
const route = useRoute()

// 自定义暗色主题
const customDarkTheme = {
  ...darkTheme,
  common: {
    ...darkTheme.common,
    baseColor: '#000000',
    cardColor: '#1a1a1a',
    modalColor: '#1a1a1a',
    popoverColor: '#1a1a1a',
    // 其他组件的背景色
    primaryColor: '#007aff',
    primaryColorHover: '#0066cc',
    primaryColorPressed: '#005299',
  },
}

// 主题切换函数
const toggleTheme = () => {
  isDark.value = !isDark.value
}
</script>

<template>
  <n-config-provider :theme="isDark ? customDarkTheme : lightTheme">
    <n-message-provider>
      <div class="app-container" :class="{ 'dark-mode': isDark }">
        <router-view v-slot="{ Component }">
          <keep-alive>
            <component :is="Component" v-if="route.meta.keepAlive" />
          </keep-alive>
          <component :is="Component" v-if="!route.meta.keepAlive" />
        </router-view>
      </div>
    </n-message-provider>
  </n-config-provider>
</template>

<style lang="scss">
:root {
  --primary-color: #007aff;
  --secondary-color: #5856d6;
  --success-color: #34c759;
  --warning-color: #ff9500;
  --error-color: #ff3b30;
  --background-light: #ffffff;
  --background-dark: #000000;
  --card-background-dark: #1a1a1a;
  --text-light: #333333;
  --text-dark: #ffffff;
  --text-secondary-dark: #8e8e93;
  --border-color: rgba(0, 0, 0, 0.08);
  --border-color-dark: rgba(255, 255, 255, 0.12);

  &.dark-mode {
    --border-color: var(--border-color-dark);
  }
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans',
    'Helvetica Neue', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  line-height: 1.5;
}

.app-container {
  min-height: 100vh;
  background-color: var(--background-light);
  color: var(--text-light);
  transition: all 0.3s ease;

  &.dark-mode {
    background-color: var(--background-dark);
    color: var(--text-dark);
  }
}

// 全局过渡动画
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
