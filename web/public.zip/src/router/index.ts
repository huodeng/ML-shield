import { createRouter, createWebHistory } from 'vue-router'
import MainLayout from '@/layouts/MainLayout.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),// 路由模式
  routes: [
    {
      path: '/',
      component: MainLayout,
      children: [
        {
          path: '',
          name: 'home',
          component: () => import('@/views/HomeView.vue'),
          meta: {
            title: '首页',
          },
        },
        {
          path: 'model-analysis',
          name: 'model-analysis',
          component: () => import('@/views/ModelAnalysis.vue'),
          meta: {
            title: '模型分析',
            keepAlive: true
          },
        },
        {
          path:'dataset-upload',
          name:'dataset-upload',
          component: () => import('@/views/DatasetUpload.vue'),
          meta: {
            title: '数据集上传',
            keepAlive: true
          }
        }
      ],
    },
  ],
})

export default router
