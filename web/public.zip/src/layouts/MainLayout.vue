<script setup lang="ts">
import { NLayout, NLayoutHeader, NLayoutSider, NLayoutContent, NButton, NIcon } from 'naive-ui'
import { Sunny as Sun, Moon, HomeOutline, AnalyticsOutline, MenuOutline,CloudUploadOutline } from '@vicons/ionicons5'
import { useStorage } from '@vueuse/core'
import { useRoute,useRouter } from 'vue-router'
import { ref, h, computed } from 'vue'
import type { Component } from 'vue'
import { NMenu, NGradientText } from 'naive-ui'

const router = useRouter()
const isDark = useStorage('theme-mode', false)
const route = useRoute()
const collapsed = ref(false)
const showLogo = ref(true)
const toggleCollapsed = () => {
  collapsed.value = !collapsed.value
  showLogo.value = !showLogo.value
}

const toggleTheme = () => {
  isDark.value = !isDark.value
}

const menuOptions = [
  {
    label: '首页',
    key: 'home',
    icon: renderIcon(HomeOutline),
    path: '/',
  },

  {
    label: '数据集上传',
    key:'dataset-upload',
    icon: renderIcon(CloudUploadOutline),
    path: '/dataset-upload',
  },
  {
    label: '模型分析',
    key: 'model-analysis',
    icon: renderIcon(AnalyticsOutline),
    path: '/model-analysis',
  },
]

const currentMenuKey = computed(() => {
  return route.name?.toString() || null
})

function renderIcon(icon: Component) {
  return () => h(NIcon, null, { default: () => h(icon) })
}
</script>

<template>
  <n-layout class="main-layout" has-sider position="absolute">
    <n-layout-sider
      bordered
      collapse-mode="width"
      :collapsed-width="60"
      :width="240"
      :native-scrollbar="false"
      :inverted="isDark"
      class="sider"
      :class="{ 'dark': isDark, 'expanded': !collapsed }"
      v-model:collapsed="collapsed"
      :style="{ background: isDark ? 'var(--card-background-dark)' : 'var(--background-light)' }"
    >
      <div class="logo" :class="{ 'dark': isDark }">
        <n-gradient-text
          v-if="showLogo"
          :size="20"
          gradient="linear-gradient(90deg, #007AFF 0%, #5856D6 100%)"
        >
          {{ collapsed ? 'ML' : 'ML Security' }}
        </n-gradient-text>
        <n-button quaternary @click="toggleCollapsed">
          <n-icon size="20">
            <MenuOutline />
          </n-icon>
        </n-button>
      </div>
      <n-menu
        :value="currentMenuKey"
        :options="menuOptions"
        :collapsed="collapsed"
        :inverted="isDark"
        @update:value="
          (key) => router.push(menuOptions.find((item) => item.key === key)?.path || '/')
        "
      />
    </n-layout-sider>

    <n-layout class="content-layout" :class="{ 'collapsed': collapsed }" :native-scrollbar="false">
      <n-layout-header class="header" :class="{ 'dark': isDark }" bordered>
        <div class="header-content">
          <div class="header-left">
          </div>

          <div class="header-right" :class="{ 'dark': isDark }">
            <n-button quaternary circle @click="toggleTheme">
              <n-icon size="20">
                <Sun v-if="isDark" />
                <Moon v-else />
              </n-icon>
            </n-button>
          </div>
        </div>
      </n-layout-header>

      <n-layout-content
        class="content"
        :class="{ 'dark': isDark }"
        :native-scrollbar="false"
      >
        <router-view />
      </n-layout-content>
    </n-layout>
  </n-layout>
</template>

<style lang="scss" scoped>
:root {
  --background-light: #fff;
  --background-dark: #18181c;
  --card-background-light: #fff;
  --card-background-dark: #1f1f23;
  --text-light: #333;
  --text-dark: #fff;
  --border-color-light: #eee;
  --border-color-dark: #2f2f2f;
  --primary-color: #007AFF;
  --primary-color-hover: #0056b3;
}

.main-layout {
  height: 100vh;
}

.sider {
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  z-index: 100;
  box-shadow: 0 2px 8px var(--border-color-light);
  border-right: 1px solid var(--border-color-light);
  transition: all 0.3s ease;
  background: var(--background-light);

  &.dark {
    background: var(--card-background-dark);
    box-shadow: 0 2px 8px var(--border-color-dark);
    border-right-color: var(--border-color-dark);
  }

  .logo {
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 16px;
    border-bottom: 1px solid var(--border-color-light);
    transition: all 0.3s ease;
    overflow: hidden;
    white-space: nowrap;
  
    &.dark {
      border-bottom-color: var(--border-color-dark);
    }
  
    .n-gradient-text {
      flex: 1;
      margin-right: 8px;
    }
  
    .n-button {
      display: flex;
      align-items: center;
      justify-content: center;
      flex: none;
    }
  }
}

.content-layout {
  margin-left: 240px;
  transition: margin-left 0.3s ease;
  height: 100vh;
  overflow: hidden;

  &.collapsed {
    margin-left: 60px;
  }
}

.header {
  height: 64px;
  position: sticky;
  top: 0;
  z-index: 90;
  background: var(--background-light);
  transition: all 0.3s ease;
  border-bottom: 1px solid var(--border-color-light);

  &.dark {
    background: var(--card-background-dark);
    border-bottom-color: var(--border-color-dark);
  }
}

.header-content {
  height: 100%;
  padding: 0 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left,
.header-right {
  display: flex;
  align-items: center;
  gap: 8px;

  &.dark {
    color: var(--text-dark);
  }
}

.content {
  padding: 24px;
  background: var(--background-light);
  min-height: calc(100vh - 64px);
  transition: all 0.3s ease;
  overflow-y: auto;

  &.dark {
    background: var(--background-dark);
  }
}

@media (max-width: 768px) {
  .sider {
    transform: translateX(-100%);

    &.expanded {
      transform: translateX(0);
    }
  }

  .content-layout {
    margin-left: 0 !important;
  }

  .header-content {
    padding: 0 16px;
  }

  .content {
    padding: 16px;
  }
}
</style>
