<script setup lang="ts">
import { NCard, NSpace, NProgress, NTag, NList, NListItem, NButton, NIcon } from 'naive-ui'
import { WarningOutline, ShieldCheckmarkOutline, DocumentTextOutline } from '@vicons/ionicons5'
import { h } from 'vue'
import { useStorage } from '@vueuse/core'

const isDark = useStorage('theme-mode', false)

const props = defineProps<{
  result: {
    score: number
    vulnerabilities: Array<{
      type: string
      severity: 'high' | 'medium' | 'low'
      description: string
    }>
    recommendations: string[]
  } | null
}>()

type Severity = 'high' | 'medium' | 'low'
type TagType = 'error' | 'warning' | 'info' | 'success' | 'primary' | 'default'

const getSeverityColor = (severity: Severity): TagType => {
  const colors: Record<Severity, TagType> = {
    high: 'error',
    medium: 'warning',
    low: 'info',
  }
  return colors[severity]
}

const renderIcon = (icon: any) => {
  return () => h(NIcon, null, { default: () => h(icon) })
}
</script>

<template>
  <div class="result-container" v-if="result" :class="{ 'dark': isDark }">
    <n-space vertical size="large">
      <n-card title="安全评分" class="score-card" :class="{ 'dark': isDark }">
        <div class="score-content">
          <n-progress
            type="circle"
            :percentage="result.score"
            :color="result.score > 70 ? '#34C759' : result.score > 40 ? '#FF9500' : '#FF3B30'"
            :rail-color="isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'"
          />
          <div class="score-description">
            <p>{{ result.score > 70 ? '良好' : result.score > 40 ? '中等' : '风险' }}</p>
          </div>
        </div>
      </n-card>

      <n-card title="漏洞详情" class="vulnerabilities-card" :class="{ 'dark': isDark }">
        <n-list>
          <n-list-item v-for="(vuln, index) in result.vulnerabilities" :key="index">
            <n-space align="center">
              <n-icon size="20" :color="getSeverityColor(vuln.severity)">
                <WarningOutline />
              </n-icon>
              <div class="vuln-content">
                <div class="vuln-header">
                  <span class="vuln-type">{{ vuln.type }}</span>
                  <n-tag :type="getSeverityColor(vuln.severity)">
                    {{ vuln.severity.toUpperCase() }}
                  </n-tag>
                </div>
                <p class="vuln-description">{{ vuln.description }}</p>
              </div>
            </n-space>
          </n-list-item>
        </n-list>
      </n-card>

      <n-card title="优化建议" class="recommendations-card" :class="{ 'dark': isDark }">
        <n-list>
          <n-list-item v-for="(rec, index) in result.recommendations" :key="index">
            <n-space align="center">
              <n-icon size="20" color="#34C759">
                <ShieldCheckmarkOutline />
              </n-icon>
              <span>{{ rec }}</span>
            </n-space>
          </n-list-item>
        </n-list>
      </n-card>

      <n-button block type="primary" @click="$emit('generate-report')" class="report-button">
        <template #icon>
          <n-icon>
            <DocumentTextOutline />
          </n-icon>
        </template>
        生成详细报告
      </n-button>
    </n-space>
  </div>
</template>

<style lang="scss" scoped>
.result-container {
  max-width: 800px;
  margin: 0 auto;
  background: var(--background-light);
  transition: all 0.3s ease;

  &.dark {
    background: var(--background-dark);
    color: var(--text-dark);
  }
}

.score-card,
.vulnerabilities-card,
.recommendations-card {
  background: var(--card-background-light);
  transition: all 0.3s ease;

  &.dark {
    background: var(--card-background-dark);
    color: var(--text-dark);
  }
}

.score-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;

  .score-description {
    margin-top: 16px;
    font-size: 1.2rem;
    font-weight: 500;
    color: var(--text-light);

    .dark & {
      color: var(--text-dark);
    }
  }
}

.vuln-content {
  flex: 1;

  .vuln-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;

    .vuln-type {
      font-weight: 500;
      color: var(--text-light);

      .dark & {
        color: var(--text-dark);
      }
    }
  }

  .vuln-description {
    color: var(--text-light);
    font-size: 0.9rem;

    .dark & {
      color: var(--text-dark);
    }
  }
}

.report-button {
  margin-top: 16px;
}
</style>
