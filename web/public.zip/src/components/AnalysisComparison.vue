<script setup lang="ts">
import { computed, h } from 'vue'
import { NCard, NSpace, NGrid, NGridItem, NDataTable, NTag } from 'naive-ui'
import { useStorage } from '@vueuse/core'
import type { AnalysisRecord } from '@/stores/analysis'
import type { DataTableColumns } from 'naive-ui'

const isDark = useStorage('theme-mode', false)

const props = defineProps<{
  records: AnalysisRecord[]
}>()

const columns = computed<DataTableColumns<AnalysisRecord>>(() => {
  if (!props.records.length) {
    return [
      {
        title: '模型名称',
        key: 'modelName',
      },
      {
        title: '总体评分',
        key: 'score',
      },
      {
        title: '高危漏洞',
        key: 'highVulns',
      }
    ] as DataTableColumns<AnalysisRecord>
  }

  return [
    {
      title: '模型名称',
      key: 'modelName',
    },
    {
      title: '总体评分',
      key: 'score',
      render: (row: AnalysisRecord) => row.result.score,
      sorter: (a: AnalysisRecord, b: AnalysisRecord) => a.result.score - b.result.score,
    },
    ...props.records[0].result.categories.map((cat) => ({
      title: cat.name,
      key: cat.name,
      render: (row: AnalysisRecord) => {
        const score = row.result.categories.find((c) => c.name === cat.name)?.score || 0
        return h(
          'span',
          { style: { color: getScoreColor(score) } },
          score.toFixed(1)
        )
      },
      sorter: (a: AnalysisRecord, b: AnalysisRecord) => {
        const scoreA = a.result.categories.find((c) => c.name === cat.name)?.score || 0
        const scoreB = b.result.categories.find((c) => c.name === cat.name)?.score || 0
        return scoreA - scoreB
      },
    })),
    {
      title: '高危漏洞',
      key: 'highVulns',
      render: (row: AnalysisRecord) => {
        const count = row.result.vulnerabilities.filter((v) => v.severity === 'high').length
        return count ? h(NTag, { type: 'error' }, { default: () => count }) : '无'
      },
    },
  ] as DataTableColumns<AnalysisRecord>
})

const getScoreColor = (score: number) => {
  if (score > 70) return '#34C759'
  if (score > 40) return '#FF9500'
  return '#FF3B30'
}

const summaryData = computed(() => {
  const records = props.records
  return {
    averageScore: records.reduce((sum, r) => sum + r.result.score, 0) / records.length,
    categories: props.records[0].result.categories.map((cat) => ({
      name: cat.name,
      average:
        records.reduce((sum, r) => {
          const score = r.result.categories.find((c) => c.name === cat.name)?.score || 0
          return sum + score
        }, 0) / records.length,
    })),
    totalHighVulns: records.reduce(
      (sum, r) => sum + r.result.vulnerabilities.filter((v) => v.severity === 'high').length,
      0,
    ),
  }
})
</script>

<template>
  <n-card title="批量分析对比" class="comparison-card" :class="{ 'dark': isDark }">
    <n-space vertical size="large">
      <n-grid :cols="4" :x-gap="12">
        <n-grid-item>
          <n-card size="small" title="平均评分" :class="{ 'dark': isDark }">
            <div class="stat-value" :style="{ color: getScoreColor(summaryData.averageScore) }">
              {{ summaryData.averageScore.toFixed(1) }}
            </div>
          </n-card>
        </n-grid-item>
        <n-grid-item>
          <n-card size="small" title="分析模型数" :class="{ 'dark': isDark }">
            <div class="stat-value">{{ records.length }}</div>
          </n-card>
        </n-grid-item>
        <n-grid-item>
          <n-card size="small" title="高危漏洞总数" :class="{ 'dark': isDark }">
            <div class="stat-value error">{{ summaryData.totalHighVulns }}</div>
          </n-card>
        </n-grid-item>
        <n-grid-item>
          <n-card size="small" title="最佳评分类别" :class="{ 'dark': isDark }">
            <div class="stat-value">
              {{
                summaryData.categories.length > 0
                  ? summaryData.categories.reduce(
                      (best, cat) => (cat.average > best.average ? cat : best),
                      summaryData.categories[0]
                    ).name
                  : '无数据'
              }}
            </div>
          </n-card>
        </n-grid-item>
      </n-grid>

      <n-data-table
        :columns="columns"
        :data="records"
        :pagination="{ pageSize: 5 }"
        :bordered="false"
      />
    </n-space>
  </n-card>
</template>

<style lang="scss" scoped>
.comparison-card {
  margin-bottom: 20px;
  background: var(--card-background-light);
  transition: all 0.3s ease;

  &.dark {
    background: var(--card-background-dark);
    color: var(--text-dark);
  }
}

.stat-value {
  font-size: 24px;
  font-weight: 500;
  text-align: center;
  color: var(--text-light);
  transition: color 0.3s ease;

  .dark & {
    color: var(--text-dark);
  }

  &.error {
    color: var(--error-color);
  }
}
</style>
