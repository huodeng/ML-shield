<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { NCard } from 'naive-ui'
import { useStorage } from '@vueuse/core'
import * as echarts from 'echarts'

interface ChartData {
  score: number
  categories: Array<{
    name: string
    score: number
  }>
}

const props = defineProps<{
  data: ChartData
}>()

const isDark = useStorage('theme-mode', false)
const chartRef = ref<HTMLElement>()
let chart: echarts.ECharts | null = null

const handleResize = () => {
  chart?.resize()
}

const chartOptions = computed(() => ({
  backgroundColor: 'transparent',
  radar: {
    indicator: props.data.categories.map((cat) => ({
      name: cat.name,
      max: 100,
    })),
    splitArea: {
      areaStyle: {
        color: isDark.value
          ? ['rgba(255,255,255,0.02)', 'rgba(255,255,255,0.05)']
          : ['rgba(0,0,0,0.02)', 'rgba(0,0,0,0.05)'],
      },
    },
    axisLine: {
      lineStyle: {
        color: isDark.value ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
      },
    },
    splitLine: {
      lineStyle: {
        color: isDark.value ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
      },
    },
  },
  series: [
    {
      type: 'radar',
      data: [
        {
          value: props.data.categories.map((cat) => cat.score),
          name: '安全评分',
          areaStyle: {
            color: isDark.value ? 'rgba(0, 122, 255, 0.2)' : 'rgba(0, 122, 255, 0.1)',
          },
          lineStyle: {
            color: '#007AFF',
            width: 2,
          },
          itemStyle: {
            color: '#007AFF',
            borderWidth: 2,
          },
          symbol: 'circle',
          symbolSize: 6,
        },
      ],
    },
  ],
}))

onMounted(() => {
  if (chartRef.value) {
    chart = echarts.init(chartRef.value)
    chart.setOption(chartOptions.value)
    window.addEventListener('resize', handleResize)
  }
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  chart?.dispose()
})

// 监听主题变化
watch(isDark, () => {
  chart?.setOption(chartOptions.value)
})
</script>

<template>
  <n-card title="安全评分分布" class="chart-card">
    <div ref="chartRef" class="chart-container"></div>
  </n-card>
</template>

<style lang="scss" scoped>
.chart-container {
  height: 300px;
  width: 100%;
}

.chart-card {
  margin-bottom: 20px;

  :deep(.n-card-header) {
    font-weight: 500;
  }
}
</style>
