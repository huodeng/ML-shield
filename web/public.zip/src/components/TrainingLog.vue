<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { NCard, NSpace, NButton, NIcon, NScrollbar, NTag, NPopconfirm } from 'naive-ui'
import { TrashOutline, DownloadOutline } from '@vicons/ionicons5'
import { useStorage } from '@vueuse/core'

const isDark = useStorage('theme-mode', false)
const logs = ref<Array<{ message: string; level: 'info' | 'warning' | 'error' | 'success'; timestamp: string }>>([]);

const props = defineProps<{
  modelId?: string
}>()

// 添加日志
const addLog = (message: string, level: 'info' | 'warning' | 'error' | 'success' = 'info') => {
  logs.value.push({
    message,
    level,
    timestamp: new Date().toLocaleTimeString()
  })
}

// 清空日志
const clearLogs = () => {
  logs.value = []
}

// 导出日志
const exportLogs = () => {
  const logText = logs.value
    .map(log => `[${log.timestamp}] [${log.level.toUpperCase()}] ${log.message}`)
    .join('\n')
  
  const blob = new Blob([logText], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `training-log-${new Date().toISOString()}.txt`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// 获取日志标签类型
const getLogTagType = (level: string) => {
  const types = {
    info: 'info',
    warning: 'warning',
    error: 'error',
    success: 'success'
  }
  return types[level as keyof typeof types] || 'default'
}

// 暴露方法给父组件
defineExpose({
  addLog
})
</script>

<template>
  <n-card
    title="训练日志"
    :bordered="false"
    :class="{ 'dark': isDark }"
    class="training-log"
  >
    <template #header-extra>
      <n-space>
        <n-popconfirm
          @positive-click="clearLogs"
          positive-text="确认"
          negative-text="取消"
        >
          <template #trigger>
            <n-button quaternary circle>
              <n-icon>
                <trash-outline />
              </n-icon>
            </n-button>
          </template>
          确定要清空所有日志吗？
        </n-popconfirm>
        <n-button quaternary circle @click="exportLogs">
          <n-icon>
            <download-outline />
          </n-icon>
        </n-button>
      </n-space>
    </template>

    <n-scrollbar style="max-height: 300px" class="log-container">
      <div v-if="logs.length === 0" class="empty-logs">
        暂无日志信息
      </div>
      <div v-else class="log-list">
        <div v-for="(log, index) in logs" :key="index" class="log-item">
          <span class="log-time">[{{ log.timestamp }}]</span>
          <n-tag :type="getLogTagType(log.level) as 'default' | 'primary' | 'error' | 'info' | 'warning' | 'success'" size="small" class="log-level">
            {{ log.level.toUpperCase() }}
          </n-tag>
          <span class="log-message">{{ log.message }}</span>
        </div>
      </div>
    </n-scrollbar>
  </n-card>
</template>

<style lang="scss" scoped>
.training-log {
  margin-top: 16px;

  &.dark {
    background: var(--card-background-dark);
    color: var(--text-dark);
  }

  .log-container {
    padding: 8px;
  }

  .empty-logs {
    text-align: center;
    color: #999;
    padding: 20px 0;
  }

  .log-list {
    .log-item {
      margin-bottom: 8px;
      font-family: monospace;
      display: flex;
      align-items: center;
      gap: 8px;

      .log-time {
        color: #666;
        font-size: 0.9em;
      }

      .log-level {
        min-width: 60px;
        text-align: center;
      }

      .log-message {
        flex: 1;
        word-break: break-all;
      }
    }
  }
}
</style>