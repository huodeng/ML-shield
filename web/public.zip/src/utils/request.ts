import axios from 'axios';
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { useAuthStore } from '@/stores/auth';
import { ElMessage } from 'element-plus';
import router from '@/router';

const baseURL = 'http://localhost:5000/api';

class Request {
  private instance: AxiosInstance;
  private authStore = useAuthStore();

  constructor() {
    this.instance = axios.create({
      baseURL,
      timeout: 10000
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // 请求拦截器
    this.instance.interceptors.request.use(
      (config) => {
        // 获取认证信息
        const token = this.authStore.token;
        const apiKey = this.authStore.apiKey;

        // 添加认证头
        if (apiKey) {
          config.headers['X-API-Key'] = apiKey;
        } else if (token) {
          config.headers['Authorization'] = `Bearer ${token}`;
        }

        return config;
      },
      (error) => {
        ElMessage.error('请求配置错误');
        return Promise.reject(error);
      }
    );

    // 响应拦截器
    this.instance.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        if (error.response) {
          const errorMessage = error.response.data?.message || '请求失败';
          switch (error.response.status) {
            case 401:
              // 认证失败，清除认证信息
              this.authStore.clearAuth();
              ElMessage.error('认证失败，请重新登录');
              // 可以在这里添加重定向到登录页的逻辑
              router.push('/login');
              break;
            case 403:
              ElMessage.error('没有权限访问该资源');
              break;
            case 429:
              ElMessage.warning('请求过于频繁，请稍后再试');
              break;
            case 500:
              ElMessage.error('服务器错误');
              break;
            default:
              ElMessage.error(errorMessage);
          }
        } else if (error.request) {
          ElMessage.error('网络连接失败，请检查网络设置');
        } else {
          ElMessage.error('请求配置错误');
        }
        return Promise.reject(error);
      }
    );
  }

  // 封装请求方法
  public request<T = any>(config: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.instance.request(config);
  }

  public get<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.instance.get(url, config);
  }

  public post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.instance.post(url, data, config);
  }

  public put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.instance.put(url, data, config);
  }

  public delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.instance.delete(url, config);
  }
}

export const request = new Request();