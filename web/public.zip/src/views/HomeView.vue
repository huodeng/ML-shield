<script setup lang="ts">
import { NCard, NButton, NSpace, NGradientText } from 'naive-ui'
import { useRouter } from 'vue-router'
import { useStorage } from '@vueuse/core'

const router = useRouter()
const isDark = useStorage('theme-mode', false)

const navigateToAnalysis = () => {
  router.push('/model-analysis')
}

const features = [
  {
    title: '模型安全评估',
    description: '支持多种攻击模拟，包括对抗攻击、数据投毒等安全风险评估',
    icon: '🛡️',
  },
  {
    title: '隐私保护分析',
    description: '全面的隐私风险评估，包括模型推断和成员推断分析',
    icon: '🔒',
  },
  {
    title: '安全优化建议',
    description: '提供模型训练优化建议，如对抗训练、差分隐私等防护措施',
    icon: '💡',
  },
]
</script>

<template>
  <div class="home-container" :class="{ 'dark': isDark }">
    <div class="hero-section">
      <h1 class="title">
        <n-gradient-text :size="48" gradient="linear-gradient(90deg, #007AFF 0%, #5856D6 100%)">
          ML Security Simulator
        </n-gradient-text>
      </h1>
      <p class="subtitle">全面的机器学习模型安全性与隐私风险评估平台</p>
      <div class="feature-cards">
        <n-card
          v-for="feature in features"
          :key="feature.title"
          class="feature-card"
          :segmented="{ content: true }"
          :bordered="false"
        >
          <div class="feature-content">
            <div class="feature-icon">{{ feature.icon }}</div>
            <h3>{{ feature.title }}</h3>
            <p>{{ feature.description }}</p>
          </div>
        </n-card>
      </div>

      <div class="action-section">
        <n-button type="primary" size="large" @click="navigateToAnalysis"> 开始分析 </n-button>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.home-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  min-height: calc(100vh - 64px);
  display: flex;
  flex-direction: column;
  background: var(--background-light);
  color: var(--text-light);
  transition: all 0.3s ease;

  &.dark {
    background: var(--background-dark);
    color: var(--text-dark);
  }
}

.hero-section {
  text-align: center;
  padding:  0 60px;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;

  .title {
    margin-bottom: 20px;
    font-weight: 800;
  }

  .subtitle {
    font-size: 1.5rem;
    color: var(--text-light);
    margin-bottom: 60px;
    max-width: 800px;

    .dark & {
      color: var(--text-dark);
    }
  }
}

.feature-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  margin: 40px 0;
  width: 100%;
  max-width: 1200px;
}

.feature-card {
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease;
  background: var(--card-background-light);

  .dark & {
    background: var(--card-background-dark);
  }

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);

    .dark & {
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      background: var(--card-background-dark-hover);
    }
  }

  .feature-content {
    text-align: center;
    padding: 20px;

    .feature-icon {
      font-size: 48px;
      margin-bottom: 20px;
    }

    h3 {
      font-size: 1.25rem;
      margin-bottom: 16px;
      color: var(--primary-color);
    }

    p {
      color: var(--text-light);
      line-height: 1.6;

      .dark & {
        color: var(--text-dark);
      }
    }
  }
}

.action-section {
  margin-top: 40px;

  :deep(.n-button) {
    padding: 0 40px;
    height: 48px;
    font-size: 1.1rem;
  }
}

// 响应式设计
@media (max-width: 768px) {
  .hero-section {
    padding: 40px 0;

    .title {
      font-size: 32px;
    }

    .subtitle {
      font-size: 1.2rem;
      margin-bottom: 40px;
    }
  }

  .feature-cards {
    grid-template-columns: 1fr;
    gap: 16px;
    margin: 40px 0;
  }
}
</style>
