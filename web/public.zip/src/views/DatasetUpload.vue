<template>
  <div class="dataset-upload">
    <div class="cards-container">
      <!-- 基本配置卡片 -->
      <el-card class="config-card">
        <template #header>
          <div class="card-header">
            <h3>基本配置</h3>
          </div>
        </template>
        
        <el-form :model="formData" label-width="120px">
          <!-- 图片大小设置 -->
          <el-form-item label="图片大小">
            <el-select v-model="formData.imgsize" placeholder="请选择图片大小" @change="handleImgsizeChange">
              <el-option label="32x32" :value="32" />
              <el-option label="64x64" :value="64" />
              <el-option label="128x128" :value="128" />
            </el-select>
          </el-form-item>

          <!-- 是否上传数据集 -->
          <el-form-item label="上传数据集">
            <el-switch
              v-model="formData.isuplord"
              @change="handleIsuploadChange"
              active-text="是"
              inactive-text="否"
            />
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 数据集上传卡片 -->
      <el-card v-if="formData.isuplord" class="upload-card">
        <template #header>
          <div class="card-header">
            <h3>数据集上传</h3>
          </div>
        </template>

        <el-upload
          class="dataset-uploader"
          drag
          action="http://localhost:5000/upload"
          :auto-upload="true"
          :show-file-list="true"
          :on-success="handleUploadSuccess"
          :on-error="handleUploadError"
          :on-progress="handleUploadProgress"
        >
          <el-icon class="el-icon--upload"><upload-filled /></el-icon>
          <div class="el-upload__text">
            将文件拖到此处，或<em>点击上传</em>
          </div>
        </el-upload>

        <!-- 状态提示 -->
        <el-alert
          v-if="message.show"
          :title="message.content"
          :type="message.type"
          show-icon
          :closable="true"
          @close="message.show = false"
          style="margin-top: 20px;"
        />
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import axios from 'axios'
import { UploadFilled } from '@element-plus/icons-vue'
import { useStorage } from '@vueuse/core'

// 使用useStorage持久化表单数据
const formData = useStorage('dataset-upload-form', {
  imgsize: 32,
  isuplord: true
})

// 消息提示状态
const message = reactive({
  show: false,
  content: '',
  type: 'success'
})

// 显示消息提示
const showMessage = (content, type = 'success') => {
  message.show = true
  message.content = content
  message.type = type
}

// 处理配置变更
const handleConfigChange = async () => {
  try {
    const response = await axios.post('http://localhost:5000/config', {
      imgsize: formData.value.imgsize,
      isuplord: formData.value.isuplord
    })
    if (response.data.status === 'success') {
      showMessage('配置更新成功')
    }
  } catch (error) {
    showMessage(error.response?.data?.detail?.message || '配置更新失败', 'error')
  }
}

// 处理图片大小变化
const handleImgsizeChange = (value) => {
  formData.value.imgsize = value
  handleConfigChange()
}

// 处理是否上传数据集变化
const handleIsuploadChange = (value) => {
  formData.value.isuplord = value
  handleConfigChange()
}

// 处理上传成功
const handleUploadSuccess = (response) => {
  if (response.status === 'success') {
    showMessage('数据集上传成功')
  }
}

// 处理上传错误
const handleUploadError = (error) => {
  showMessage(error.message || '数据集上传失败', 'error')
}

// 处理上传进度
const handleUploadProgress = (event) => {
  // 可以在这里处理上传进度
}
</script>

<style scoped>
.dataset-upload {
  padding: 20px;
}

.cards-container {
  display: flex;
  flex-direction: column;
  gap: 20px;
  max-width: 800px;
  margin: 0 auto;
}

.config-card,
.upload-card {
  width: 100%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.el-form-item {
  margin-bottom: 20px;
}

.dataset-uploader {
  width: 100%;
}

.el-upload__text {
  margin-top: 10px;
  color: #606266;
}

.el-upload__text em {
  color: #409EFF;
  font-style: normal;
}
</style>