<template>
  <div class="api-key-management">
    <h1 class="text-2xl font-bold mb-6">API密钥管理</h1>

    <!-- API密钥说明 -->
    <div class="bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200">
      <p class="text-gray-600">
      </p>
    </div>

    <!-- API密钥列表 -->
    <div class="api-keys-list">
      <h2 class="text-lg font-semibold mb-4">API密钥列表</h2>
      <el-table :data="apiKeys" style="width: 100%" v-loading="isLoading" border>
        <el-table-column prop="key" label="API密钥" min-width="300">
          <template #default="{ row }">
            <div class="flex items-center gap-2">
              <span class="font-mono">{{ maskApiKey(row.key) }}</span>
              <el-button link type="primary" @click="copyApiKey(row.key)">
                <el-icon class="mr-1"><Document /></el-icon>复制
              </el-button>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="created_at" label="创建时间" width="180">
          <template #default="{ row }">
            {{ formatDate(row.created_at) }}
          </template>
        </el-table-column>
        <el-table-column prop="last_used" label="最后使用时间" width="180">
          <template #default="{ row }">
            {{ row.last_used ? formatDate(row.last_used) : '从未使用' }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-popconfirm
              title="确定要撤销这个API密钥吗？"
              confirm-button-text="确定"
              cancel-button-text="取消"
              @confirm="revokeApiKey(row.key)"
            >
              <template #reference>
                <el-button
                  type="danger"
                  link
                  :loading="isDeletingKey === row.key"
                >
                  <el-icon class="mr-1"><Delete /></el-icon>撤销
                </el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <!-- 空状态展示 -->
      <el-empty
        v-if="!isLoading && (!apiKeys || apiKeys.length === 0)"
        description="暂无API密钥"
      >
        <el-button type="primary" @click="createNewApiKey">创建新的API密钥</el-button>
      </el-empty>
    </div>

    <!-- 新密钥创建成功对话框 -->
    <el-dialog
      v-model="showNewKeyDialog"
      title="新的API密钥"
      width="500px"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <div class="text-center">
        <el-alert
          type="warning"
          :closable="false"
          class="mb-4"
        >
        </el-alert>
        <div class="bg-gray-50 p-4 rounded-lg mb-4 border border-gray-200">
          <code class="text-lg font-mono break-all">{{ newApiKey }}</code>
        </div>
        <el-button type="primary" @click="copyNewApiKey" class="mb-4">
          <el-icon class="mr-1"><Document /></el-icon>复制密钥
        </el-button>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="closeNewKeyDialog" type="primary">我已保存密钥</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { request } from '@/utils/request'
import { ElMessage } from 'element-plus'
import { Plus, Document, Delete } from '@element-plus/icons-vue'

interface ApiKey {
  key: string
  created_at: string
  last_used: string | null
}

const authStore = useAuthStore()

// 状态变量
const apiKeys = ref<ApiKey[]>([])
const isLoading = ref(true)
const isCreating = ref(false)
const isDeletingKey = ref<string | null>(null)
const showNewKeyDialog = ref(false)
const newApiKey = ref('')

// 获取API密钥列表
const fetchApiKeys = async () => {
  try {
    isLoading.value = true
    const response = await request.get('/keys')
    if (response.data.status === 'success') {
      apiKeys.value = response.data.api_keys
    }
  } catch (error) {
    ElMessage.error('获取API密钥列表失败')
    console.error('获取API密钥列表失败:', error)
  } finally {
    isLoading.value = false
  }
}

// 创建新的API密钥
const createNewApiKey = async () => {
  if (isCreating.value) return

  try {
    isCreating.value = true
    const response = await request.post('/keys')
    if (response.data.status === 'success') {
      newApiKey.value = response.data.api_key
      showNewKeyDialog.value = true
      ElMessage.success('API密钥创建成功')
      await fetchApiKeys()
    }
  } catch (error) {
    ElMessage.error('创建API密钥失败')
    console.error('创建API密钥失败:', error)
  } finally {
    isCreating.value = false
  }
}

// 撤销API密钥
const revokeApiKey = async (key: string) => {
  if (isDeletingKey.value) return

  try {
    isDeletingKey.value = key
    await request.delete(`/keys/${key}`)
    ElMessage.success('API密钥已撤销')
    await fetchApiKeys()
  } catch (error) {
    ElMessage.error('撤销API密钥失败')
    console.error('撤销API密钥失败:', error)
  } finally {
    isDeletingKey.value = null
  }
}

// 复制API密钥
const copyApiKey = async (key: string) => {
  try {
    await navigator.clipboard.writeText(key)
    ElMessage.success('API密钥已复制到剪贴板')
  } catch (error) {
    ElMessage.error('复制失败')
    console.error('复制API密钥失败:', error)
  }
}

// 复制新创建的API密钥
const copyNewApiKey = async () => {
  try {
    await navigator.clipboard.writeText(newApiKey.value)
    ElMessage.success('API密钥已复制到剪贴板')
  } catch (error) {
    ElMessage.error('复制失败')
    console.error('复制新API密钥失败:', error)
  }
}

// 关闭新密钥对话框
const closeNewKeyDialog = () => {
  showNewKeyDialog.value = false
  newApiKey.value = ''
}

// 格式化日期
const formatDate = (dateString: string) => {
  try {
    return new Date(dateString).toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    })
  } catch (error) {
    console.error('日期格式化失败:', error)
    return dateString
  }
}

// 遮蔽API密钥
const maskApiKey = (key: string) => {
  if (!key) return ''
  return `${key.slice(0, 8)}...${key.slice(-8)}`
}

// 组件挂载时获取API密钥列表
onMounted(() => {
  fetchApiKeys()
})
</script>

<style scoped>
.api-key-management {
  padding: 24px;
}

.el-table {
  margin-bottom: 20px;
}

.el-empty {
  padding: 40px 0;
}

.mr-1 {
  margin-right: 4px;
}
</style>