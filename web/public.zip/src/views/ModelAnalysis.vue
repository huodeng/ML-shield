<script setup lang="ts">
import { ref } from 'vue'
import {
  NCard,
  NSpace,
  NSelect,
  NButton,
  NIcon,
  NProgress,
  useMessage,
  NCollapseTransition,
  NFormItem,
  NSlider,
  NInputNumber,
  NSwitch,
  NList,
  NListItem,
  NTag,
  NDrawer,
  NDrawerContent,
  NDescriptions,
  NDescriptionsItem,
} from 'naive-ui'
import { WarningOutline, AnalyticsOutline, AlertCircleOutline, ShieldCheckmarkOutline } from '@vicons/ionicons5'
import AnalysisResult from '@/components/AnalysisResult.vue'
import SecurityChart from '@/components/SecurityChart.vue'
import ReportGenerator from '@/components/ReportGenerator.vue'
import AnalysisTrend from '@/components/AnalysisTrend.vue'
import AnalysisComparison from '@/components/AnalysisComparison.vue'
import { useAnalysisStore } from '@/stores/analysis'
import { useStorage } from '@vueuse/core'
import FileUploader from '@/components/FileUploader.vue'
import TrainingLog from '@/components/TrainingLog.vue'

const isDark = useStorage('theme-mode', false)
const cachedComponents = ref<string[]>(['FileUploader'])

interface AnalysisResultType {
  score: number
  categories: Array<{
    name: string
    score: number
  }>
  vulnerabilities: Array<{
    type: string
    severity: 'high' | 'medium' | 'low'
    description: string
  }>
  recommendations: string[]
}

interface ModelFile {
  id: string
  name: string
  status: 'pending' | 'analyzing' | 'completed' | 'error'
  result?: AnalysisResultType
}

const message = useMessage()
const analysisType = useStorage('analysis-type', null)
const showAdvancedConfig = useStorage('show-advanced-config', false)
const advancedConfig = useStorage('advanced-config', {
  attackStrength: 0.3,
  iterations: 100,
  targetAccuracy: 0.8
})
const batchMode = useStorage('batch-mode', false)
const analyzing = ref(false)
const showResult = ref(false)
const analysisResult = ref<AnalysisResultType | null>(null)
const modelFiles = ref<ModelFile[]>([])
const showReport = ref(false)
const analysisProgress = ref(0)
const trainingLogRef = ref()

const analysisStore = useAnalysisStore()

const analysisOptions = [
  {
    label: '对抗攻击评估',
    value: 'all',
    description: '全面评估模型在面对对抗样本时的防御能力，包括FGSM、PGD等主流白盒攻击和迁移攻击等黑盒攻击场景。',
    principle: '通过梯度信息或启发式方法生成微扰动样本，测试模型对输入扰动的敏感性和决策边界的稳定性。',
    impact: '模型可能在微小扰动下产生误判，在安全攸关场景（如自动驾驶、医疗诊断）可能造成严重后果。',
    defense: '推荐采用对抗训练、随机化防御、特征压缩等技术增强模型鲁棒性，构建多层防御机制。'
  },
  {
    label: '数据投毒分析',
    value: 'backdoor',
    description: '深入检测模型训练数据中的潜在后门和触发器，评估数据投毒攻击的影响范围和成功率。',
    principle: '分析训练数据分布异常和模型行为特征，识别可能被植入的后门触发模式和攻击目标。',
    impact: '攻击者可通过触发特定模式操控模型行为，在特定场景下引发定向误分类，威胁系统可靠性。',
    defense: '建议结合神经元修剪、模型净化、对抗验证等技术，同时加强数据质量控制和异常检测机制。'
  },
  {
    label: '模型推断风险',
    value: 'dlg',
    description: '评估模型结构、参数和训练策略的保密性，防范模型克隆和知识产权盗取风险。',
    principle: '通过系统化的黑盒查询和输出分析，结合优化算法重建模型架构和关键参数信息。',
    impact: '可能导致核心算法泄露、商业模型被复制，并为定向攻击提供详细的目标信息。',
    defense: '推荐实施模型加密、梯度扰动、预测结果量化等技术手段，构建多层次的模型保护方案。'
  },
  {
    label: '成员推断风险',
    value: 'mia',
    description: '全面评估模型在保护训练数据隐私方面的能力，识别潜在的数据成员泄露风险。',
    principle: '利用模型对训练样本和非训练样本的预测置信度差异，推断目标数据是否参与模型训练。',
    impact: '可能泄露敏感训练数据的成员身份，在医疗、金融等领域造成严重的隐私泄露问题。',
    defense: '建议采用差分隐私训练、知识蒸馏、预测结果泛化等技术，平衡模型性能和隐私保护需求。'
  },
]


const showAttackInfo = ref(false)
const selectedAttack = ref<typeof analysisOptions[0] | null>(null)

const handleAnalysisTypeChange = (value: string) => {
  const attack = analysisOptions.find(option => option.value === value)
  if (attack) {
    selectedAttack.value = attack
    showAttackInfo.value = true
  }
}


const startAnalysis = async () => {
  
  if (!analysisType.value) {
    message.warning('请选择分析类型')
    return
  }
  if (batchMode.value) {
    if (modelFiles.value.length === 0) {
      message.warning('请先上传模型文件')
      return
    }
  }

  try {
    analyzing.value = true
    analysisProgress.value = 0
    trainingLogRef.value?.addLog('开始模型分析...', 'info')
    
    // 模拟进度更新
    const progressInterval = setInterval(() => {
      if (analysisProgress.value < 90) {
        analysisProgress.value += 10
        trainingLogRef.value?.addLog(`分析进度: ${analysisProgress.value}%`, 'info')
      }
    }, 1000)

    const response = await fetch('/api/run', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        method: analysisType.value,
        use_privacy : false,
      })
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    clearInterval(progressInterval)
    analysisProgress.value = 100
    trainingLogRef.value?.addLog('分析完成！', 'success')

    const result = await response.json()
    console.log('分析结果:', result)
    analysisResult.value = result
    showResult.value = true
    
    // 更新分析历史
    analysisStore.addAnalysisRecord({
      id: Date.now().toString(),
      date: new Date().toISOString(),
      modelName: batchMode.value ? '批量分析' : '单模型分析',
      result: result
    })

  } catch (error) {
    trainingLogRef.value?.addLog(`分析失败: ${(error as Error).message}`, 'error')
    message.error(`分析失败: ${(error as Error).message}`)
  } finally {
    analyzing.value = false
  }
}

const generateMockResult = (): AnalysisResultType => {
  return {
    score: Math.floor(Math.random() * 40) + 40,
    categories: [
      { name: '对抗攻击防御', score: Math.floor(Math.random() * 100) },
      { name: '模型鲁棒性', score: Math.floor(Math.random() * 100) },
      { name: '数据隐私保护', score: Math.floor(Math.random() * 100) },
      { name: '模型保密性', score: Math.floor(Math.random() * 100) },
      { name: '访问控制', score: Math.floor(Math.random() * 100) },
    ],
    vulnerabilities: [
      {
        type: '对抗样本攻击',
        severity: Math.random() > 0.5 ? 'high' : 'medium',
        description: '模型对FGSM攻击具有较高敏感性，可能导致错误分类。',
      },
      {
        type: '模型推断风险',
        severity: Math.random() > 0.7 ? 'high' : 'medium',
        description: '模型架构可能通过黑盒攻击被推断出来。',
      },
    ],
    recommendations: [
      '建议实施对抗训练来增强模型鲁棒性',
      '考虑使用模型压缩或知识蒸馏技术',
      '添加差分隐私机制保护训练数据',
    ],
  }
}

const generateReport = () => {
  showReport.value = true
}
</script>

<template>
  
  <div class="analysis-container" :class="{ 'dark': isDark }" >
    <n-space vertical size="large">
      
      <n-card title="模型上传" class="upload-card">
        <file-uploader />
      </n-card>
      
      <!-- 文件列表 -->
      <keep-alive :include="cachedComponents">
      <n-card v-if="batchMode && modelFiles.length > 0" title="文件列表">
        <n-list>
          <n-list-item v-for="file in modelFiles" :key="file.id">
            <n-space justify="space-between" align="center">
              <span>{{ file.name }}</span>
              <n-tag
                :type="
                  file.status === 'completed'
                    ? 'success'
                    : file.status === 'analyzing'
                      ? 'warning'
                      : 'default'
                "
              >
                {{
                  file.status === 'completed'
                    ? '已完成'
                    : file.status === 'analyzing'
                      ? '分析中'
                      : '待分析'
                }}
              </n-tag>
            </n-space>
          </n-list-item>
        </n-list>
      </n-card>
      </keep-alive>
      <n-card title="分析配置" class="config-card">
        <n-space vertical>
          <n-select
            v-model:value="analysisType"
            :options="analysisOptions"
            placeholder="选择分析类型"
            @update:value="handleAnalysisTypeChange"
          />

          <n-button text @click="showAdvancedConfig = !showAdvancedConfig">
            {{ showAdvancedConfig ? '隐藏高级配置' : '显示高级配置' }}
          </n-button>

          <n-collapse-transition :show="showAdvancedConfig">
            <div class="advanced-config">
              <n-form-item label="攻击强度">
                <n-slider
                  v-model:value="advancedConfig.attackStrength"
                  :step="0.1"
                  :min="0"
                  :max="1"
                />
              </n-form-item>

              <n-form-item label="迭代次数">
                <n-input-number v-model:value="advancedConfig.iterations" :min="1" :max="1000" />
              </n-form-item>

              <n-form-item label="目标准确率">
                <n-slider
                  v-model:value="advancedConfig.targetAccuracy"
                  :step="0.05"
                  :min="0"
                  :max="1"
                />
              </n-form-item>

              <n-form-item label="隐私预算">
                <n-input-number
                  v-model:value="(advancedConfig as any).privacyBudget"
                  :min="0.1"
                  :max="10"
                  :step="0.1"
                />
              </n-form-item>
            </div>
          </n-collapse-transition>

          <n-button
            type="primary"
            block
            :loading="analyzing"
            :disabled="!analysisType"
            @click="startAnalysis"
          >
            {{ analyzing ? '分析中...' : '开始分析' }}
          </n-button>
        </n-space>
      </n-card>

      
      <n-card title="分析进度" v-if="analyzing">
        <n-space vertical>
          <n-progress
            type="line"
            :percentage="analysisProgress"
            :height="24"
            processing
          />
          <div class="progress-text">分析进度：{{ analysisProgress }}%</div>
        </n-space>
      </n-card>
      
      
      <AnalysisResult
        v-if="showResult"
        :result="analysisResult"
        @generate-report="generateReport"
      />

      <SecurityChart
        v-if="showResult && analysisResult"
        :data="{
          score: analysisResult.score,
          categories: analysisResult.categories,
        }"
      />
<!-- 
      <AnalysisTrend v-if="analysisStore.analysisHistory.length > 0" /> -->

      <!-- <ReportGenerator v-model:show="showReport" :data="analysisResult" v-if="analysisResult" /> -->
<!-- 
      <AnalysisComparison
        v-if="batchMode && modelFiles.filter((f) => f.status === 'completed').length > 1"
        :records="
          modelFiles
            .filter((f) => f.status === 'completed' && f.result)
            .map((f) => ({
              id: f.id,
              date: new Date().toISOString(),
              modelName: f.name,
              result: f.result!,
            }))
        "
      /> -->
    </n-space>
    
    <!-- 攻击信息抽屉 -->
    <n-drawer v-model:show="showAttackInfo" :width="480" placement="right">
      <n-drawer-content v-if="selectedAttack" :title="selectedAttack.label + ' - 详细信息'" class="attack-info-drawer">
        <n-descriptions label-placement="left" :column="1" class="attack-descriptions">
          <n-descriptions-item label="攻击描述" label-style="font-weight: bold; color: var(--primary-color);">
            <div class="description-content">
              <n-icon size="20" class="description-icon">
                <warning-outline />
              </n-icon>
              {{ selectedAttack.description }}
            </div>
          </n-descriptions-item>
          <n-descriptions-item label="攻击原理" label-style="font-weight: bold; color: var(--primary-color);">
            <div class="description-content">
              <n-icon size="20" class="description-icon">
                <analytics-outline />
              </n-icon>
              {{ selectedAttack.principle }}
            </div>
          </n-descriptions-item>
          <n-descriptions-item label="影响范围" label-style="font-weight: bold; color: var(--primary-color);">
            <div class="description-content">
              <n-icon size="20" class="description-icon">
                <alert-circle-outline />
              </n-icon>
              {{ selectedAttack.impact }}
            </div>
          </n-descriptions-item>
          <n-descriptions-item label="防御建议" label-style="font-weight: bold; color: var(--primary-color);">
            <div class="description-content">
              <n-icon size="20" class="description-icon">
                <shield-checkmark-outline />
              </n-icon>
              {{ selectedAttack.defense }}
            </div>
          </n-descriptions-item>
        </n-descriptions>
      </n-drawer-content>
    </n-drawer>
  </div>
</template>

<style lang="scss" scoped>
.analysis-container {
  max-width: 800px;
  margin: 0 auto;
}

.upload-card,
.config-card {
  background: var(--background-light);

  .dark & {
    background: var(--card--background-dark);
  }

}

.upload-trigger {
  margin-top: 8px;
  color: #999;
}

.advanced-config {
  padding: 16px;
  background: rgba(0, 0, 0, 0.02);
  border-radius: 6px;
  margin: 8px 0;

  :deep(.dark-mode) & {
    background: rgba(255, 255, 255, 0.02);
  }
}

.file-list {
  margin-top: 16px;

  .file-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid var(--border-color);

    &:last-child {
      border-bottom: none;
    }
  }
}

.batch-controls {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid var(--border-color);
}
</style>

.progress-text {
  text-align: center;
  margin-top: 8px;
  color: var(--text-color-secondary);
}

.attack-info-drawer {
  .attack-descriptions {
    padding: 16px;
    
    .description-content {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 12px;
      background: var(--card-color);
      border-radius: 8px;
      margin: 8px 0;
      
      .description-icon {
        color: var(--primary-color);
        flex-shrink: 0;
        margin-top: 2px;
      }
    }
  }
}
