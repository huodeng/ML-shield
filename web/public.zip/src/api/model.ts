import axios from 'axios';

interface InitModelParams {
  imgsize?: number;
}

interface LoadAndAttackParams {
  attack_type?: string;
  use_privacy?: boolean;
}

interface ApiResponse<T = any> {
  status: 'success' | 'error';
  message: string;
  data?: T;
}

// 初始化模型
export const initModel = async (params: InitModelParams = {}) => {
  const { data } = await axios.post<ApiResponse>('/api/init', params);
  return data;
};

// 上传模型文件
export const uploadModelFile = async (file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  
  const { data } = await axios.post<ApiResponse>('/api/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
  return data;
};

// 加载数据并执行攻击
export const loadAndAttack = async (params: LoadAndAttackParams = {}) => {
  const { data } = await axios.post<ApiResponse>('/api/load-and-attack', params);
  return data;
};

// 获取任务状态
export const getTaskStatus = async (taskId: string) => {
  const { data } = await axios.get<ApiResponse>(`/api/task/${taskId}`);
  return data;
};